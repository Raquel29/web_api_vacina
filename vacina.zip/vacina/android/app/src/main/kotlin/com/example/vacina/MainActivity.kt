package com.example.vacina

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

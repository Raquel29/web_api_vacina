import 'package:flutter/material.dart';
import 'package:vacina/view/lista_vacina.dart';
void main() {
  runApp(VacinaApp());
}
  class VacinaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
  return MaterialApp(
  theme: ThemeData(
  primaryColor: Colors.orange[800],
  accentColor: Colors.orange[800],
  buttonTheme: ButtonThemeData(
  buttonColor: Colors.orange[800],
  textTheme: ButtonTextTheme.primary,
  ),
  ),
  home: ListaVacina(),
  );
  }
  }
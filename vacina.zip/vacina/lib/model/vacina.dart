class Vacina {
  int id;
  String nome;
  String cpf;
  String cidade;
  String laboratorio;
  String nomeResponsavel;
  String dataAplica;
  String dataSegunda;

  Vacina(this.nome, this.cpf, this.cidade, this.laboratorio, this.nomeResponsavel, this.dataAplica, this.dataSegunda,{required this.id});

  Map<String, dynamic> toJson() => {
    "id": id,
    "nome": nome,
    "cpf": cpf,
    "cidade": cidade,
    "laboratorio": laboratorio,
    "nomeResponsavel": nomeResponsavel,
    "dataAplica": dataAplica,
    "dataSegunda": dataSegunda,
  };

  Vacina.fromJson(Map<String, dynamic> json)
      : id = json["id"],
        nome = json["nome"],
        cpf = json["cpf"],
        cidade = json["cidade"],
        laboratorio = json["laboratorio"],
        nomeResponsavel = json["nomeResponsavel"],
        dataAplica = json["dataAplica"],
        dataSegunda = json["dataSegunda"];

  @override
  String toString() {
    return "Nome: $nome \n CPF: $cpf \n Cidade: $cidade \n NomeResponsavel: $nomeResponsavel \n DataAplica: $dataAplica \n DataSegunda: $dataSegunda\n Laboratorio: $laboratorio";
  }
}

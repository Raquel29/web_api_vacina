import 'dart:convert';
import 'dart:ffi';
//import 'dart:ffi';
import 'package:http/http.dart';
import 'package:vacina/model/vacina.dart';
import '../web_client.dart';

class VacinaWebClient {
  Future<List<Vacina>> findAll() async {
    final Response response = await client.get(Uri.http(baseUrl, api)).timeout(Duration(seconds: 5));
    final List<dynamic> decodedJson = jsonDecode(utf8.decode(response.bodyBytes));
    return decodedJson
        .map((dynamic json) => Vacina.fromJson(json))
        .toList();
  }

  Future<Vacina> salvar(Vacina vacina) async {
    Response response;
    if (vacina.id == null) {
      response = await client.post(Uri.http(baseUrl, api),
          headers: {
            'Content-type': 'application/json',
          },
          body: jsonEncode(vacina.toJson()));
    } else {
      Uri alterar = Uri.http(baseUrl, api + "/${vacina.id}");
      response = await client.put(alterar,
          headers: {
            'Content-type': 'application/json',
          },
          body: jsonEncode(vacina.toJson()));
    }
    return Vacina.fromJson(jsonDecode(response.body));
  }
  Future<Void> excluir(int id) async {
    Response response;
    Uri deletar = Uri.http(baseUrl, api + "/${id}");
    response = await client.delete(deletar, headers: {'Content-type': 'application/json',});
  }
 /* Future<int> excluir(int id) async {
    Response response;
    Uri deletar = Uri.http(baseUrl, api + "/${id}");
    response = await client.delete(deletar, headers: {
      'Content-type': 'application/json',
    });
    return id;
  }*/
}
import 'package:flutter/material.dart';
import 'package:vacina/http/webclient/vacina_webclient.dart';
import 'package:vacina/model/vacina.dart';
import 'package:vacina/view/cadastro_vacina.dart';
import 'package:vacina/view/lista_vacina.dart';

class VacinaItem extends StatefulWidget {
  Vacina _vacina;

  List<Vacina> _listaVacinas;
  int _index;
  VacinaItem(this._vacina, this._listaVacinas, this._index);

  @override
  _VacinaItemState createState() => _VacinaItemState();
}

class _VacinaItemState extends State<VacinaItem> {

  late Vacina _ultimoRemovido;
  VacinaWebClient _vacinaWebClient = VacinaWebClient();
  _atualizarLista() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ListaVacina(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(DateTime.now().millisecondsSinceEpoch.toString()),
      background: Container(
        color: Colors.red,
        child: Align(
          alignment: Alignment(-0.9, 0.0),
          child: Icon(
            Icons.delete,
            color: Colors.white,
          ),
        ),
      ),
      direction: DismissDirection.startToEnd,
      child: Card(
        color: Colors.orange[800],
        child: ListTile(
          title: Text(
            widget._vacina.nome,
            style: TextStyle(
              fontSize: 16.0,
            ),
          ),
          subtitle: Text(
            widget._vacina.cpf,
            style: TextStyle(
            fontSize: 12.0,
          ),
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CadastroVacina(
                vacina: widget._listaVacinas[widget._index],
              ),
            ),
          );
        },
      ),
    ),
    onDismissed: (direction) {
    setState(() {
    mostrarAlerta(context);
    });
    },
    );
  }
  mostrarAlerta(BuildContext context) {
    Widget botaoNao = TextButton(
      child: Text(
        "Não",
        style: TextStyle(color: Colors.white),
      ),
      onPressed: () {
        _atualizarLista();
      },
    );
    Widget botaoSim = TextButton(
      child: Text(
        "Sim",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
      onPressed: () {
        _ultimoRemovido = widget._listaVacinas[widget._index];
        widget._listaVacinas.removeAt(widget._index);
        _vacinaWebClient.excluir(_ultimoRemovido.id);
        _atualizarLista();
      },
    );

    AlertDialog alerta = AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
      backgroundColor: Colors.orange[800],
      title: Text(
        "Aviso",
        style: TextStyle(color: Colors.black),
      ),
      content: Text(
        "Deseja apagar o registro?",
        style: TextStyle(color: Colors.white),
      ),
      actions: [
        botaoNao,
        botaoSim,
      ],
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alerta;
      },
    );
  }
}


import 'package:flutter/material.dart';
import 'package:vacina/component/curso_item.dart';
import 'package:vacina/http/webclient/vacina_webclient.dart';
import 'package:vacina/model/vacina.dart';

import 'cadastro_vacina.dart';
//import 'package:web_api_vacina/http/web_client.dart';
//import 'package:web_api_vacina/view/cadastro_vacina.dart';

class ListaVacina extends StatefulWidget {

  @override
  _ListaVacinaState createState() => _ListaVacinaState();
}

class _ListaVacinaState extends State<ListaVacina> {

  List<Vacina> _listaVacinas = [];

  VacinaWebClient _vacinaWebClient = VacinaWebClient();

  @override
  void initState() {
    super.initState();
    _vacinaWebClient.findAll().then((dados) {
      setState(() {
        _listaVacinas = dados;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Lista de vacinas"),
      ),
      body: FutureBuilder<List<Vacina>>(
        initialData: _listaVacinas,
        future: _vacinaWebClient.findAll(),
        // ignore: missing_return
        builder: (context, snapshot){
          switch(snapshot.connectionState){
            case ConnectionState.none:
              break;
            case ConnectionState.waiting:
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    CircularProgressIndicator(),
                    Text("Carregando..."),
                  ],
                ),
              );
              break;
            case ConnectionState.active:
              break;
            case ConnectionState.done:
              final List<Vacina>? vacinas = snapshot.data;
              return ListView.builder(
                itemBuilder: (context, index){
                  final Vacina vacina = vacinas![index];
                  return VacinaItem(vacina,_listaVacinas,index);
                },
                itemCount: vacinas!.length,
              );
          }
          return Text("Erro");
        },
      ),
      /*floatingActionButton: FloatingActionButton(
        onPressed: (){
          setState(() {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) =>  CadastroVacina(),
              ),
              ),
            );
          });
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.orange[800],
      ),*/
    );
  }
}

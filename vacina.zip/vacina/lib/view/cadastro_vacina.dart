import 'package:flutter/material.dart';
import 'package:vacina/component/cria_dropdown.dart';
import 'package:vacina/component/cria_textfield.dart';
import 'package:vacina/http/webclient/vacina_webclient.dart';
import 'package:vacina/model/vacina.dart';
import 'lista_vacina.dart';
import 'package:vacina/view/lista_vacina.dart';

class CadastroVacina extends StatefulWidget {
  final Vacina vacina;
  CadastroVacina({ required this.vacina});
  @override
  _CadastroVacinaState createState() => _CadastroVacinaState();
}

class _CadastroVacinaState extends State<CadastroVacina> {
  late int _id;
  TextEditingController _nomeController = TextEditingController();
  TextEditingController _cpfController = TextEditingController();
  TextEditingController _cidadeController = TextEditingController();
  TextEditingController _nomeResponsavelController = TextEditingController();
  TextEditingController _dataAplicaController = TextEditingController();
  TextEditingController _dataSegundaController = TextEditingController();
  TextEditingController _laboratorioController = TextEditingController();

  VacinaWebClient _vacinaWebClient = VacinaWebClient();

  var _laboratorio = ["CORONAVAC", "PFIZER", "ASTRAZENECA"];
  var _laboratorioSelecionado = "ASTRAZENECA";
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  _alterarLaboratorio(String novoLaboratorioSelecionado) {
    _dropDownLaboratorioSelected(novoLaboratorioSelecionado);
    setState(() {
      this._laboratorioSelecionado = novoLaboratorioSelecionado;
      _laboratorioController.text = this._laboratorioSelecionado;
    });
  }

  _dropDownLaboratorioSelected(String novoLaboratorio) {
    setState(() {
      this._laboratorioSelecionado = novoLaboratorio;
    });
  }

  _displaySnackBar(BuildContext context, String mensagem) {
    final snackBar = SnackBar(
      content: Text(mensagem),
      backgroundColor: Colors.green[900],);
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  _salvar(BuildContext context) {
    Vacina vacina = Vacina(_nomeController.text, _cpfController.text, _cidadeController.text,
        _nomeResponsavelController.text, _dataAplicaController.text, _dataSegundaController.text, _laboratorioSelecionado, id: _id);
    setState(() {
      _vacinaWebClient.salvar(vacina).then((res) {
        setState(() {
          _displaySnackBar(context, res.toString());
          /*Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ListaVacina()),
          );*/
        });
      });
    });
  }

  @override
  void initState() {
    // ignore: unnecessary_null_comparison
    if(widget.vacina != null){
      _id = widget.vacina.id;
      _nomeController.text = widget.vacina.nome;
      _cpfController.text = widget.vacina.cpf;
      _cidadeController.text = widget.vacina.cidade;
      _nomeResponsavelController.text = widget.vacina.nomeResponsavel;
      _dataAplicaController.text = widget.vacina.dataAplica;
      _dataSegundaController.text = widget.vacina.dataSegunda;
      _laboratorioSelecionado = widget.vacina.laboratorio;
    }else{
      _id = 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text("Cadastro de vacina"),
        centerTitle: true,
        leading: new IconButton(
          icon: new Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ListaVacina()),
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: criaTextField("Nome", _nomeController, TextInputType.text),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: criaTextField("Cpf", _cpfController,
                  TextInputType.text),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: criaTextField("Cidade", _cidadeController,
                  TextInputType.text),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: criaTextField("Nome Responsável", _nomeResponsavelController,
                  TextInputType.text),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: criaTextField("Data Aplica", _dataAplicaController,
                  TextInputType.text),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: criaTextField("Data Segunda", _dataSegundaController,
                  TextInputType.text),
            ),
            Container(
              padding: EdgeInsets.all(16.0),
              child: Row(
                children: <Widget>[
                  Text(
                    "Laboratorio:",
                    style: TextStyle(color: Colors.orange[800]),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16.0),
                    child: criaDropDownButton(_laboratorio, _alterarLaboratorio,
                        _laboratorioSelecionado),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.maxFinite,
                child: ElevatedButton.icon(
                  onPressed: () {
                    _salvar(context);
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.orange[800],
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10.0))),
                    onPrimary: Colors.green,
                  ),
                  label: Text('Salvar',
                    style: TextStyle(color: Colors.white),
                  ),
                  icon: Icon(
                    Icons.save,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}